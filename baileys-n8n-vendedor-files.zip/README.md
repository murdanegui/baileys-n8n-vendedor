
# Bot WhatsApp + n8n + IA (Vendedor)

Este repositorio contiene el código base de un bot de WhatsApp utilizando Baileys,
que se conecta con n8n para automatizar respuestas inteligentes usando inteligencia artificial (OpenAI).

## Archivos

- index.js: Código principal del bot
- package.json: Dependencias del proyecto
- README.md: Esta guía

## ¿Cómo se conecta?

1. El bot recibe mensajes por WhatsApp (usando Baileys)
2. Reenvía esos mensajes a un Webhook en n8n
3. n8n procesa el mensaje con OpenAI y responde
4. El bot envía la respuesta de vuelta al cliente

Puedes modificar el endpoint del webhook en `index.js`.

---
